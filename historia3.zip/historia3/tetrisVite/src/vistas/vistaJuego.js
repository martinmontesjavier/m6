export const juego = {
    template: '',
    script: () =>{
        
    }
}