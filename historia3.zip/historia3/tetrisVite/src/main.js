import { header } from "./componentes/header"
import { principal } from "./vistas/vistaPrincipal"


document.querySelector('header').innerHTML = header.template
header.script()


