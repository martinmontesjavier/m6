// vite.config.js
import { defineConfig } from 'vite'
export default defineConfig({
  // Directorio raíz de tu proyecto
  root: './src'
})
